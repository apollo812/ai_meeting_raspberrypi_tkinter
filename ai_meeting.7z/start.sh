#!/bin/bash

cd /home/crossbox/Desktop/aimeeting/
source venv/bin/activate
python main.py